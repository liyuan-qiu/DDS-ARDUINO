Copy to C:\Users\[USERNAME]\Documents\Arduino\libraries
or install "ClickButton" library in Arduino IDE:
"Sketch"->"Include Library"->"Manage Libraries" - type "ClickButton" ->"Install"